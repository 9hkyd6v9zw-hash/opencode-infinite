#pragma once
// egress.h - exit-route control: WARP, Tor, free proxy lists, WireGuard (wireproxy), VPN Gate (OpenVPN), direct.
#include <string>
#include <functional>
#include <memory>
#include <set>
#include <vector>
#include <atomic>

#include "config.h"
#include "torbridge.h"

namespace oi {

enum class Egress { None, Warp, Tor, Proxy, Wireproxy, VpnGate };

const char* egressName(Egress e);
Egress      egressFromName(const std::string& s);

// true when the VPN Gate helper answers (no administrator prompt, no state change)
bool vgHelperAlive();

struct EgressState {
    Egress      mode = Egress::None;
    std::string proxyUrl;      // http://127.0.0.1:40000  (empty when direct)
    std::string activeProxy;   // host:port, PROXY mode only
    std::string lastIp;
    std::string lastLoc;
    bool warpFound = false;
    bool torFound = false;
    bool ourTor = false;       // this launcher started Tor
    std::string nodeOptions;   // VPNGATE: IPv4-first for Node children (the .bat sets NODE_OPTIONS)
};

// kind: 0 info, 1 ok, 2 warn, 3 error
using ProgressFn = std::function<void(int kind, const std::string& msg)>;

struct TraceInfo {
    bool ok = false;
    std::string ip;
    std::string loc;
    std::string warp;      // "on" / "plus" / "off"
    std::string raw;
};

class EgressEngine {
public:
    EgressEngine(Config* cfg, EgressState* st);
    ~EgressEngine();

    void detectTools();

    bool setMode(const std::string& name, ProgressFn log);   // WARP/TOR/PROXY/WIREGUARD/VPNGATE/NONE
    bool up(ProgressFn log);                                  // bring the mode up
    bool rotate(ProgressFn log);                              // one new route

    TraceInfo trace(int timeoutSec = 15) const;
    bool  routeOk(const TraceInfo& t) const;
    bool  targetMatch(const std::string& ip, const std::string& loc) const;

    // 0 = usable, 1 = burned (limit answer), 2 = probe itself broken
    int probe(ProgressFn log, const std::string& cli, const std::string& model);

    // Rotate until the target matches and the probe accepts. Runs until that happens or cancel() is called.
    bool hunt(ProgressFn log, const std::string& cli);
    void cancel() { cancelHunt_ = true; }

    // IP pool: routes that worked, kept for the next rotation (PROXY, WIREGUARD, VPNGATE).
    bool poolUse(ProgressFn log);                                   // rotation: take a saved route first
    bool poolFillOne(ProgressFn log, const std::string& cli, const std::string& curIp, bool useProbe);
    void asPoolWorker() { runTag_ = "pool"; }                       // worker engine: never tears down the session
    void resume() { cancelHunt_ = false; }                          // the pool worker is used again
    bool tunnelUp() const { return vpnUp_.load(); }                 // a VPN Gate tunnel is up in this engine

    void shutdown();

    std::string torDir() const;
    std::string torLogPath() const;

private:
    std::atomic<bool> cancelHunt_{false};
    bool rotateRoute(ProgressFn log);                        // one mode-specific rotation, unchecked
    bool warpAvailable() const;
    bool warpCall(const std::string& args, int timeoutSec, std::string* out = nullptr) const;
    bool warpUp(ProgressFn log);
    bool warpSvcFix(ProgressFn log);
    bool warpRotate(ProgressFn log);
    bool warpCheck(std::string* ip) const;

    bool torSocksUp() const;
    bool torStart(ProgressFn log);
    void torStop();
    bool torRotate(ProgressFn log);
    bool torReady(ProgressFn log);
    bool torInstall(ProgressFn log);
    std::string torExePath() const;

    bool proxyPick(ProgressFn log);
    static bool parseProxies(const std::string& text, std::vector<std::string>& out);

    // WireGuard through wireproxy (.bat: OC_VPN_PS). A local HTTP proxy, no adapter, no administrator prompt.
    bool wgSwitch(ProgressFn log);
    void wgStop();
    std::string wpExe(ProgressFn log);
    bool wpStart(const std::string& exe, const std::string& confPath, int port);

    // VPN Gate through OpenVPN (.bat: OC_VGATE_PS). Only OpenCode's hosts are routed into the tunnel.
    bool vgSwitch(ProgressFn log);
    void vgStop();
    std::string ovpnExe(ProgressFn log);
    bool vgEnsure(ProgressFn log);
    bool vgStart(const std::string& cfgText, const std::vector<std::string>& ips, int secs);
    void vgQuit();
    TraceInfo vgTrace() const;
    std::vector<std::string> ocIps() const;

    bool portOpen(uint16_t port, int timeoutMs) const;
    bool wgUseConf(const std::string& name, const std::string& path, ProgressFn log);
    bool vgUseHost(const std::string& host, const std::string& cfgPath, const std::vector<std::string>& ips, ProgressFn log);
    std::string wgConfPath(const std::string& name) const;
    std::set<std::string> poolTried_;   // candidates this engine already tested
    std::string runTag_;                // "" = session engine, "pool" = background worker
    std::atomic<bool> vpnUp_{false};
    static bool probeClassifyLimit(const std::string& text);

    Config* cfg_;
    EgressState* st_;
    std::unique_ptr<SocksBridge> bridge_;
    uint32_t torPid_ = 0;

    // VPN state. Failures count for this launcher session only (the .bat keeps them in vpn_failed.txt per session).
    std::set<std::string> failedWg_, failedVg_;
    std::string curName_;          // active .conf / VPN Gate host
    uint32_t wpPid_ = 0;  void* wpProc_ = nullptr;  int wpPort_ = 0;
    bool vgRoutesSet_ = false;
};

} // namespace oi
